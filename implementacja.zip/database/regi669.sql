-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Czas generowania: 27 Sty 2022, 12:02
-- Wersja serwera: 10.5.12-MariaDB-102+deb11u1
-- Wersja PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `regi669`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `appointment_list`
--

CREATE TABLE `appointment_list` (
  `id` int(30) NOT NULL,
  `fullname` text NOT NULL,
  `contact` text NOT NULL,
  `email` text NOT NULL,
  `schedule` date NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `total` float NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `appointment_list`
--

INSERT INTO `appointment_list` (`id`, `fullname`, `contact`, `email`, `schedule`, `status`, `total`, `date_created`, `date_updated`) VALUES
(1, 'John Smith', '09123456789', 'jsmith@sample.com', '2021-12-03', 1, 830, '2021-12-01 14:42:19', NULL),
(2, 'George Wilson', '0945698865', 'gwilson@sample.com', '2021-12-04', 1, 580, '2021-12-01 14:45:09', NULL),
(9, 'xxdsad', '111111111', '123@xyz.com', '2022-01-27', 1, 380, '2022-01-27 11:31:16', NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `appointment_service`
--

CREATE TABLE `appointment_service` (
  `appointment_id` int(30) NOT NULL,
  `service_id` int(30) NOT NULL,
  `cost` float NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `appointment_service`
--

INSERT INTO `appointment_service` (`appointment_id`, `service_id`, `cost`) VALUES
(1, 1, 80),
(1, 3, 250),
(1, 5, 300),
(2, 1, 80),
(2, 5, 300),
(8, 3, 250),
(9, 5, 300),
(9, 1, 80);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `service_list`
--

CREATE TABLE `service_list` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `cost` float NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `service_list`
--

INSERT INTO `service_list` (`id`, `name`, `description`, `cost`, `status`, `date_created`, `date_updated`) VALUES
(1, 'Strzyzenie Wlosow', 'Strzyzenie Wlosow', 80, 1, '2021-12-01 11:04:17', '2022-01-27 11:24:48'),
(2, 'Malowanie Wlosow', 'Malowanie Wlosow', 150, 1, '2021-12-01 11:04:31', '2022-01-27 11:24:58'),
(3, 'Strzyzenie z Myciem Glowy', 'Strzyzenie z Myciem Glowy', 250, 1, '2021-12-01 11:04:56', '2022-01-27 11:25:08'),
(4, 'Strzyzenie z Masazem Ciala', 'Strzyzenie z Masazem Ciala', 300, 1, '2021-12-01 11:05:25', '2022-01-27 11:25:17'),
(5, 'Rownanie Brody', 'Rownanie Brody', 300, 1, '2021-12-01 11:07:25', '2022-01-27 11:25:25');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `system_info`
--

CREATE TABLE `system_info` (
  `id` int(30) NOT NULL,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `system_info`
--

INSERT INTO `system_info` (`id`, `meta_field`, `meta_value`) VALUES
(1, 'name', 'Zaklad Fryzjerski - Wlos'),
(6, 'short_name', 'ZF - Wlos'),
(11, 'logo', 'uploads/ikona.jpg'),
(13, 'user_avatar', 'uploads/user_avatar.jpg'),
(14, 'cover', 'uploads/tlo.jpg'),
(15, 'content', 'Array'),
(16, 'email', 'kontakt@wlos.pl'),
(17, 'contact', '534-235-345'),
(18, 'from_time', '09:00'),
(19, 'to_time', '19:00'),
(20, 'address', 'Porzeczkowa 101, Olsztyn');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `users`
--

CREATE TABLE `users` (
  `id` int(50) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `middlename` text DEFAULT NULL,
  `lastname` varchar(250) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `avatar` text DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `status` int(1) NOT NULL DEFAULT 1 COMMENT '0=not verified, 1 = verified',
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `users`
--

INSERT INTO `users` (`id`, `firstname`, `middlename`, `lastname`, `username`, `password`, `avatar`, `last_login`, `type`, `status`, `date_added`, `date_updated`) VALUES
(1, 'Adminstrator', NULL, 'Admin', 'admin', '0192023a7bbd73250516f069df18b500', 'uploads/avatar-1.png?v=1635556826', NULL, 1, 1, '2021-01-20 14:02:37', '2021-11-27 13:39:11'),
(4, 'Fryzjer', NULL, 'Nowy', 'fryzjer1', '4085945e2573bfad583cb1c896f5011b', NULL, NULL, 2, 1, '2022-01-27 09:37:17', '2022-01-27 10:07:40');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `appointment_list`
--
ALTER TABLE `appointment_list`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `appointment_service`
--
ALTER TABLE `appointment_service`
  ADD KEY `appointment_id` (`appointment_id`),
  ADD KEY `service_id` (`service_id`);

--
-- Indeksy dla tabeli `service_list`
--
ALTER TABLE `service_list`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `system_info`
--
ALTER TABLE `system_info`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT dla zrzuconych tabel
--

--
-- AUTO_INCREMENT dla tabeli `appointment_list`
--
ALTER TABLE `appointment_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT dla tabeli `service_list`
--
ALTER TABLE `service_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT dla tabeli `system_info`
--
ALTER TABLE `system_info`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT dla tabeli `users`
--
ALTER TABLE `users`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
